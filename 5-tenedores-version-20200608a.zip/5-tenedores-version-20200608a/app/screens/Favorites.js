import * as React from 'react';
import { Text, View } from 'react-native';

export default function Favorites() {
  return (
    <View>
      <Text>Favorites... </Text>
    </View>
  );
}