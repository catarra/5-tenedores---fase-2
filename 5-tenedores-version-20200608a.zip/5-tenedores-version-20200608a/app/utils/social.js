export const FacebookApi = {
  application_id: "2971222739613631",
  permissions: ["public_profile"],
};
